require("dotenv").config();

const express = require("express");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");

//Credentials
const port = process.env.PORT;
const username = process.env.USERNAME;
const password = process.env.PASSWORD;
const db = process.env.DB;

//Register Schemas
const Restaurant = require("./api/models/RestaurantSchema");
const Category = require("./api/models/CategorySchema");
const MenuItem = require("./api/models/MenuItemSchema");

//Connect to  MongoDB
mongoose.Promise = global.Promise;
mongoose.connect(`mongodb+srv://${username}:${password}@cluster0.dma5m.gcp.mongodb.net/${db}?retryWrites=true&w=majority`, {useNewUrlParser: true, useUnifiedTopology: true});

//Create app
const app = express();

app.use(bodyParser.urlencoded({extended: true}));
app.use(bodyParser.json());

//Register routes
const routes = require("./api/routes/routes");
routes(app);

//Start app
app.listen(port);
console.log("Now listening on port " + port + " for requests.");