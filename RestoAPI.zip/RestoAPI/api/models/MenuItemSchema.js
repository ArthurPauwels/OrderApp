const mongoose = require("mongoose");

const Schema = mongoose.Schema;

const MenuItemSchema = new Schema({
    name: {
        type: "String",
        required: "A menu item name is required"
    },
    description: {
        type: "String",
        required: "A short menu item description is required"
    },
    price: {
        type: Number,
        required: "A price is required"
    },
    _categoryId: {
        type: mongoose.ObjectId,
        required: "A reference to a category is required"
    }
});

module.exports = mongoose.model("MenuItems", MenuItemSchema);