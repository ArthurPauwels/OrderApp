const mongoose = require("mongoose");
const rs = require("randomstring");

function GetHumanId() {
    let baseString = rs.generate({
        length: 8,
        charset: 'alphanumeric'
    });
    
    let capsString = baseString.toUpperCase();
    
    return readableString = capsString.substr(0, 4) + "-" + capsString.substr(4,7);
}

const Schema = mongoose.Schema;

const RestaurantSchema = new Schema({
    name: {
        type: "String",
        required: "A restaurant name is required"
    },
    description: {
        type: "String",
        required: " A short restaurant description is required"
    },
    openingHours: {
        type: Map,
        of: "String",
        required: "At least one opening hour is required"
    },
    paymentMethods: {
        type: Map,
        of: "String",
        required: "At least one payment method is required"
    },
    amenities: {
        type: [String]
    },
    _humanId: {
        type: String,
        default: GetHumanId()
    }
});

module.exports = mongoose.model("Restaurants", RestaurantSchema);