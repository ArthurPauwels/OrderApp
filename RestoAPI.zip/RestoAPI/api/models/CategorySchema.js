const mongoose = require("mongoose");

const Schema = mongoose.Schema;

const CategorySchema = new Schema({
    name: {
        type: "String",
        required: "A category name is required"
    },
    _restoId: {
        type: mongoose.ObjectId,
        required: "A reference to a restaurant is required"
    }
});

module.exports = mongoose.model("Categories", CategorySchema);