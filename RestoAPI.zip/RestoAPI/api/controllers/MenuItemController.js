const mongoose = require("mongoose");

const MenuItem = mongoose.model("MenuItems");

exports.get_all = function(req, res) {
    MenuItem.find({}, function(err, menuItem) {
        if(err) {
            res.send(err);
        } else {
            res.json(menuItem);
        }
    });
};

exports.create_new = function(req, res) {
    let new_menuItem = new MenuItem(req.body);
    new_menuItem.save(function(err, menuItem) {
        if(err) {
            res.send(err);
        } else {
            res.json(menuItem);
        }
    });
};

exports.get_by_id = function(req, res) {
    MenuItem.findById(req.params.id, function(err, menuItem) {
        if(err) {
            res.send(err);
        } else {
            res.json(menuItem);
        }
    });
};

exports.update_by_id = function(req, res) {
    MenuItem.findOneAndUpdate({_id: req.params.id}, req.body, {new: true}, function(err, menuItem){
        if(err) {
            res.send(err);
        } else {
            res.json(menuItem);
        }
    });
};

exports.delete_by_id = function(req, res) {
    MenuItem.deleteOne({_id: req.params.id}, function(err, menuItem) {
        if(err) {
            res.send(err);
        } else {
            res.json({message: "MenuItem succesfully deleted!"});
        }
    });
};

exports.get_by_category_id = function(req, res) {
    MenuItem.find({_categoryId: req.params.id}, function(err, menuItem) {
        if(err) {
            res.send(err);
        } else {
            res.json(menuItem);
        }
    });
};