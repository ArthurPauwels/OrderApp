const mongoose = require("mongoose");

const Restaurant = mongoose.model("Restaurants");

exports.get_all = function(req, res) {
    Restaurant.find({}, function(err, restaurant) {
        if(err) {
            res.send(err);
        } else {
            res.json(restaurant);
        }
    });
};

exports.create_new = function(req, res) {
    let new_restaurant = new Restaurant(req.body);
    new_restaurant.save(function(err, restaurant) {
        if(err) {
            res.send(err);
        } else {
            res.json(restaurant);
        }
    });
};

exports.get_by_human_id = function(req, res) {
    Restaurant.findOne({_humanId: req.params.id}, function(err, restaurant) {
        if(err) {
            res.send(err);
        } else {
            res.json(restaurant);
        }
    });
}

exports.get_by_id = function(req, res) {
    Restaurant.findById(req.params.id, function(err, restaurant) {
        if(err) {
            res.send(err);
        } else {
            res.json(restaurant);
        }
    });
};

exports.update_by_id = function(req, res) {
    Restaurant.findOneAndUpdate({_id: req.params.id}, req.body, {new: true}, function(err, restaurant){
        if(err) {
            res.send(err);
        } else {
            res.json(restaurant);
        }
    });
};

exports.delete_by_id = function(req, res) {
    Restaurant.deleteOne({_id: req.params.id}, function(err, restaurant) {
        if(err) {
            res.send(err);
        } else {
            res.json({message: "Restaurant succesfully deleted!"});
        }
    });
};