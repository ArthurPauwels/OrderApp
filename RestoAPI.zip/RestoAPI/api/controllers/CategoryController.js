const mongoose = require("mongoose");

const Category = mongoose.model("Categories");

exports.get_all = function(req, res) {
    Category.find({}, function(err, category) {
        if(err) {
            res.send(err);
        } else {
            res.json(category);
        }
    });
};

exports.create_new = function(req, res) {
    let new_category = new Category(req.body);
    new_category.save(function(err, category) {
        if(err) {
            res.send(err);
        } else {
            res.json(category);
        }
    });
};

exports.get_by_id = function(req, res) {
    Category.findById(req.params.id, function(err, category) {
        if(err) {
            res.send(err);
        } else {
            res.json(category);
        }
    });
};

exports.update_by_id = function(req, res) {
    Category.findOneAndUpdate({_id: req.params.id}, req.body, {new: true}, function(err, category){
        if(err) {
            res.send(err);
        } else {
            res.json(category);
        }
    });
};

exports.delete_by_id = function(req, res) {
    Category.deleteOne({_id: req.params.id}, function(err, category) {
        if(err) {
            res.send(err);
        } else {
            res.json({message: "Category succesfully deleted!"});
        }
    });
};

exports.get_by_restaurant_id = function(req, res) {
    Category.find({_restoId: req.params.id}, function(err, category) {
        if(err) {
            res.send(err);
        } else {
            res.json(category);
        }
    });
};