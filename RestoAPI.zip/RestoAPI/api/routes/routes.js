module.exports = function(app) {
    const restaurants = require("../controllers/RestaurantController");
    const categories = require("../controllers/CategoryController");
    const menuItems = require("../controllers/MenuItemController");
    const orders = require("../controllers/OrderController");

    app.route("/restaurants")
        .get(restaurants.get_all)
        .post(restaurants.create_new);

    app.route("/restaurants/human/:id")
        .get(restaurants.get_by_human_id)

    app.route("/restaurants/:id")
        .get(restaurants.get_by_id)
        .put(restaurants.update_by_id)
        .delete(restaurants.delete_by_id);

    app.route("/categories")
        .get(categories.get_all)
        .post(categories.create_new);

    app.route("/categories/:id")
        .get(categories.get_by_id)
        .put(categories.update_by_id)
        .delete(categories.delete_by_id);

    app.route("/categories/restaurant/:id")
        .get(categories.get_by_restaurant_id);

    app.route("/menuitems")
        .get(menuItems.get_all)
        .post(menuItems.create_new);

    app.route("/menuitems/:id")
        .get(menuItems.get_by_id)
        .put(menuItems.update_by_id)
        .delete(menuItems.delete_by_id);

    app.route("/menuitems/category/:id")
        .get(menuItems.get_by_category_id);

    app.route("/orders")
        .post(orders.create_new);
}